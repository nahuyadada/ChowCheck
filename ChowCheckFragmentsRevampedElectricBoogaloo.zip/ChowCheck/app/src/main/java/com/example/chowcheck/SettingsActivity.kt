package com.example.chowcheck

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.ListView
import com.example.chowcheck.frag.ProfileFragment

// Removed unused ProfileFragment import if it was here
// No need to import ProfileFragment here anymore

class SettingsActivity : Activity() {

    private lateinit var listView: ListView
    private lateinit var buttonGoBack: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        listView = findViewById(R.id.settingsListView)
        buttonGoBack = findViewById(R.id.btnBack)

        val settingsOptions = listOf(
            "Profile",
            "Notifications",
            "Privacy",
            "Security",
            "About Developers",
            "Logout"
        )

        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, settingsOptions)
        listView.adapter = adapter

        listView.onItemClickListener = AdapterView.OnItemClickListener { _, _, position, _ ->
            when (position) {
                // *** Start LandingActivity and tell it to show Profile ***
                0 -> {
                    val intent = Intent(this, LandingActivity::class.java)
                    intent.putExtra("LOAD_FRAGMENT", "PROFILE") // Add instruction
                    // Clear other activities on top and make LandingActivity the new task root
                    intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                    startActivity(intent)
                    finish() // Optional: close SettingsActivity after navigating
                }
                // Keep other cases as they were (assuming they start Activities correctly)
                1 -> startActivity(Intent(this, NotificationActivity::class.java))
                2 -> startActivity(Intent(this, PrivacyActivity::class.java))
                3 -> startActivity(Intent(this, SecurityActivity::class.java))
                4 -> startActivity(Intent(this, DeveloperActivity::class.java))
                5 -> showLogoutDialog()
            }
        }

        buttonGoBack.setOnClickListener {
            finish()
        }
    }

    private fun showLogoutDialog() {
        AlertDialog.Builder(this)
            .setTitle("Confirm Logout")
            .setMessage("Are you sure you want to log out?")
            .setPositiveButton("Yes") { _, _ ->
                // Ensure logout clears user data and goes to Login
                val editor = getSharedPreferences(ProfileFragment.USER_DATA_PREFS, MODE_PRIVATE).edit()
                editor.remove(ProfileFragment.KEY_LOGGED_IN_USER)
                // Optionally remove other user-specific data if needed
                editor.apply()

                val intent = Intent(this, LoginActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                startActivity(intent)
                finishAffinity() // Finish this activity and all parent activities
            }
            .setNegativeButton("No", null)
            .show()
    }
}