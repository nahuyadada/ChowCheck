package com.example.chowcheck

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator

class ResultsActivity : AppCompatActivity() {

    private lateinit var tabLayout: TabLayout
    private lateinit var viewPager: ViewPager2

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_results)

        tabLayout = findViewById(R.id.tabLayout)
        viewPager = findViewById(R.id.viewPager)

        val resultsAdapter = ResultsPagerAdapter(this)

        // Pass data to the adapter
        resultsAdapter.addFragment("Breakfast", intent.getStringExtra("BREAKFAST_DATA"))
        resultsAdapter.addFragment("Lunch", intent.getStringExtra("LUNCH_DATA"))
        resultsAdapter.addFragment("Dinner", intent.getStringExtra("DINNER_DATA"))

        viewPager.adapter = resultsAdapter

        // Setup TabLayout with ViewPager2
        TabLayoutMediator(tabLayout, viewPager) { tab, position ->
            when (position) {
                0 -> tab.text = "Breakfast"
                1 -> tab.text = "Lunch"
                2 -> tab.text = "Dinner"
            }
        }.attach()
    }
}
