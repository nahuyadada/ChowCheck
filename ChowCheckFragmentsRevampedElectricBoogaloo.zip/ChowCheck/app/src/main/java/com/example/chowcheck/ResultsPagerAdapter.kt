package com.example.chowcheck

import android.os.Bundle
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter

class ResultsPagerAdapter(activity: FragmentActivity) : FragmentStateAdapter(activity) {

    private val fragments = mutableListOf<Pair<String, String>>() // Stores tab name and data

    // Returns the number of fragments (tabs) to be displayed
    override fun getItemCount(): Int {
        return fragments.size
    }

    // Creates a fragment for each tab and passes the data
    override fun createFragment(position: Int): Fragment {
        val fragment = ResultsTabFragment()
        val fragmentData = fragments[position]
        val bundle = Bundle()
        bundle.putString("TAB_NAME", fragmentData.first)  // Tab name (Breakfast, Lunch, or Dinner)
        bundle.putString("TAB_DATA", fragmentData.second) // Tab data (Meal data)
        fragment.arguments = bundle
        return fragment
    }

    // Adds a new fragment (tab) with its name and data
    fun addFragment(tabName: String, data: String?) {
        fragments.add(Pair(tabName, data ?: "No data"))
    }
}
