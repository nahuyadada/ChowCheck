package com.example.chowcheck.frag

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import androidx.fragment.app.Fragment // Use androidx fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import android.app.Activity // Keep Activity import for MODE_PRIVATE if needed elsewhere
import com.example.chowcheck.LoginActivity
import com.example.chowcheck.R

class ProfileFragment : Fragment() {

    // Views
    private lateinit var editTextName: EditText
    private lateinit var editTextAge: EditText
    private lateinit var editTextHeight: EditText
    private lateinit var editTextWeight: EditText
    private lateinit var editTextWeightGoal: EditText
    private lateinit var buttonEditProfile: Button
    private lateinit var buttonGoBack: ImageButton
    private lateinit var textViewUsername: TextView
    // Removed bottom nav buttons (buttonGoDiary, buttonExplore, buttonResults)

    // SharedPreferences and Logged-in User
    private lateinit var userDataPreferences: SharedPreferences
    private var loggedInUsername: String? = null

    // Define base key names (consistent keys)
    companion object {
        const val USER_DATA_PREFS = "UserData"
        const val KEY_LOGGED_IN_USER = "logged_in_user"
        const val BASE_KEY_NAME = "name"
        const val BASE_KEY_AGE = "age"
        const val BASE_KEY_HEIGHT = "height"
        const val BASE_KEY_WEIGHT = "weight"
        const val BASE_KEY_WEIGHT_GOAL = "weight_goal"
        // Add other base keys if needed
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_profile, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Use requireContext() for context-dependent operations within a fragment
        userDataPreferences = requireContext().getSharedPreferences(USER_DATA_PREFS, Context.MODE_PRIVATE)

        // Get the currently logged-in user
        loggedInUsername = userDataPreferences.getString(KEY_LOGGED_IN_USER, null)

        // Redirect to Login if no user is logged in (use requireActivity() to access Activity functions)
        if (loggedInUsername == null) {
            Toast.makeText(requireContext(), "Please log in to view your profile.", Toast.LENGTH_LONG).show()
            val intent = Intent(requireActivity(), LoginActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            requireActivity().finish() // Finish the hosting activity
            return // Stop further execution in onViewCreated
        }

        // Initialize Views using the 'view' passed to onViewCreated
        initializeViews(view)

        // Load data for the logged-in user
        loadUsername()
        loadProfileData()

        // Set Listeners
        setupButtonClickListeners()
    }


    // Helper to generate user-specific data keys
    private fun getUserDataKey(username: String, baseKey: String): String {
        return "${username}_${baseKey}"
    }

    // Initialize views using the provided fragment view
    private fun initializeViews(view: View) {
        editTextName = view.findViewById(R.id.editTextName)
        editTextAge = view.findViewById(R.id.editTextAge)
        editTextHeight = view.findViewById(R.id.editTextHeight)
        editTextWeight = view.findViewById(R.id.editTextWeight)
        editTextWeightGoal = view.findViewById(R.id.editTextWeightGoal)
        buttonEditProfile = view.findViewById(R.id.btnEditProfile)
        buttonGoBack = view.findViewById(R.id.btnBack)
        textViewUsername = view.findViewById(R.id.txtUsername)
        // Note: Removed initialization for buttonGoDiary, buttonExplore, buttonResults
    }

    private fun loadUsername() {
        // Display the username obtained during onViewCreated
        textViewUsername.text = loggedInUsername ?: "Error"
    }

    private fun loadProfileData() {
        // loggedInUsername is confirmed not null here due to the earlier check
        if (loggedInUsername == null) return // Defensive check

        // Load data using USER-SPECIFIC keys
        val savedName = userDataPreferences.getString(getUserDataKey(loggedInUsername!!, BASE_KEY_NAME), "")
        val savedAge = userDataPreferences.getString(getUserDataKey(loggedInUsername!!, BASE_KEY_AGE), "")
        val savedHeight = userDataPreferences.getString(getUserDataKey(loggedInUsername!!, BASE_KEY_HEIGHT), "")
        val savedWeight = userDataPreferences.getString(getUserDataKey(loggedInUsername!!, BASE_KEY_WEIGHT), "")
        val savedWeightGoal = userDataPreferences.getString(getUserDataKey(loggedInUsername!!, BASE_KEY_WEIGHT_GOAL), "")

        // Set text in EditText fields
        editTextName.setText(savedName)
        editTextAge.setText(savedAge)
        editTextHeight.setText(savedHeight)
        editTextWeight.setText(savedWeight)
        editTextWeightGoal.setText(savedWeightGoal)
    }

    // Use baseKey to save data with user-specific prefix
    private fun saveDataToPrefs(baseKey: String, value: String) {
        if (loggedInUsername == null) return
        val editor = userDataPreferences.edit()
        editor.putString(getUserDataKey(loggedInUsername!!, baseKey), value)
        editor.apply()
    }

    private fun setupButtonClickListeners() {
        buttonEditProfile.setOnClickListener {
            if (loggedInUsername == null) {
                Toast.makeText(requireContext(), "Error: Cannot save profile. Not logged in.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Get text from EditText fields
            val name = editTextName.text.toString().trim()
            val age = editTextAge.text.toString().trim()
            val height = editTextHeight.text.toString().trim()
            val weight = editTextWeight.text.toString().trim()
            val weightGoal = editTextWeightGoal.text.toString().trim()

            // Validation
            if (!validateProfileInputs(name, age, height, weight, weightGoal)) {
                return@setOnClickListener
            }

            // Save updated data using USER-SPECIFIC keys
            saveDataToPrefs(BASE_KEY_NAME, name)
            saveDataToPrefs(BASE_KEY_AGE, age)
            saveDataToPrefs(BASE_KEY_HEIGHT, height)
            saveDataToPrefs(BASE_KEY_WEIGHT, weight)
            saveDataToPrefs(BASE_KEY_WEIGHT_GOAL, weightGoal)

            Toast.makeText(requireContext(), "Profile updated successfully", Toast.LENGTH_SHORT).show()
        }

        buttonGoBack.setOnClickListener {
            // Option 1: Finish the hosting Activity (like original code)
            requireActivity().finish()

            // Option 2: If using Navigation Component, pop back stack
            // findNavController().popBackStack()

            // Option 3: If just part of tabs, do nothing or let Activity handle back
        }

        // Removed listeners for bottom navigation buttons (should be handled by Activity)
    }

    // Validation logic (can remain mostly the same, use requireContext() for Toast)
    private fun validateProfileInputs(name: String, ageStr: String, heightStr: String, weightStr: String, weightGoalStr: String): Boolean {
        if (name.isEmpty()) {
            Toast.makeText(requireContext(), "Please enter your name", Toast.LENGTH_SHORT).show(); return false
        }
        if (ageStr.isEmpty() || ageStr.toIntOrNull() == null || ageStr.toInt() <= 0) {
            Toast.makeText(requireContext(), "Please enter a valid age", Toast.LENGTH_SHORT).show(); return false
        }
        if (heightStr.isEmpty() || heightStr.toDoubleOrNull() == null || heightStr.toDouble() <= 0) {
            Toast.makeText(requireContext(), "Please enter a valid height (cm)", Toast.LENGTH_SHORT).show(); return false
        }
        if (weightStr.isEmpty() || weightStr.toDoubleOrNull() == null || weightStr.toDouble() <= 0) {
            Toast.makeText(requireContext(), "Please enter a valid weight (kg)", Toast.LENGTH_SHORT).show(); return false
        }
        if (weightGoalStr.isEmpty() || weightGoalStr.toDoubleOrNull() == null || weightGoalStr.toDouble() <= 0) {
            Toast.makeText(requireContext(), "Please enter a valid weight goal (kg)", Toast.LENGTH_SHORT).show(); return false
        }
        return true
    }
}