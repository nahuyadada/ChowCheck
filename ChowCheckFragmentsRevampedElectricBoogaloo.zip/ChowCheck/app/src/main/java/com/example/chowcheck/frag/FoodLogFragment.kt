package com.example.chowcheck.frag // Or your correct fragment package

import android.content.Context // Added for SharedPreferences
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.ProgressBar // Removed - not in this layout
import android.widget.TextView
import android.widget.Toast
import com.example.chowcheck.R // Use correct R import
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class FoodLogFragment : Fragment() { // Renamed class

    // Declare view variables for Food Log
    private lateinit var textViewDate: TextView
    // Removed progress bar views
    private lateinit var buttonAddWater: ImageButton
    private lateinit var buttonAddBreakfast: ImageButton
    private lateinit var buttonAddLunch: ImageButton
    private lateinit var buttonAddDinner: ImageButton
    private lateinit var textViewWaterDetails: TextView
    // Add SharedPreferences if needed to load water goal etc.
    // private lateinit var userDataPreferences: SharedPreferences
    // private var loggedInUsername: String? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_food_log, container, false) // Use new layout ID
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Initialize SharedPreferences if needed
        // userDataPreferences = requireContext().getSharedPreferences("UserData", Context.MODE_PRIVATE)
        // loggedInUsername = userDataPreferences.getString("logged_in_user", null)

        // Initialize views using the inflated view
        initializeViews(view)

        // Set current date
        setCurrentDate()

        // Load data (water, potentially meal summaries if implemented)
        loadAndDisplayData()

        // Setup button listeners
        setupClickListeners()
    }

    private fun initializeViews(view: View) {
        textViewDate = view.findViewById(R.id.textViewDate)
        // Removed progress bar initialization
        buttonAddWater = view.findViewById(R.id.buttonAddWater)
        buttonAddBreakfast = view.findViewById(R.id.buttonAddBreakfast)
        buttonAddLunch = view.findViewById(R.id.buttonAddLunch)
        buttonAddDinner = view.findViewById(R.id.buttonAddDinner)
        textViewWaterDetails = view.findViewById(R.id.textViewWaterDetails)
    }

    private fun setCurrentDate() {
        val dateFormat = SimpleDateFormat("d MMMM, EEEE", Locale.getDefault())
        textViewDate.text = dateFormat.format(Date())
    }

    private fun loadAndDisplayData() {
        // --- Placeholder Data Loading ---
        // Load actual water intake and goal for the logged-in user
        // Example:
        // val waterIntakeKey = getDailyUserDataKey("water_intake") // Needs function like in LandingActivity
        // val waterGoalKey = getUserDataKey("water_goal") // Needs function like in LandingActivity
        // val waterIntakeLiters = userDataPreferences.getFloat(waterIntakeKey, 0.0f)
        // val waterGoalLiters = userDataPreferences.getFloat(waterGoalKey, 1.5f) // Default 1.5L

        // Placeholder values
        val waterIntakeLiters = 0.9
        val waterGoalLiters = 1.5

        // Update Water Text UI
        val waterProgressPercent = if (waterGoalLiters > 0) {
            (waterIntakeLiters / waterGoalLiters * 100).toInt().coerceIn(0, 100)
        } else {
            0
        }
        textViewWaterDetails.text = "Water %.1fL (%d%%)".format(waterIntakeLiters, waterProgressPercent)

        // TODO: Load and display meal summaries if needed
    }


    private fun setupClickListeners() {
        // Removed settings click listener

        buttonAddWater.setOnClickListener {
            // Example: Show a simple dialog or navigate to a water logging screen
            Toast.makeText(context, "Add Water clicked (Food Log)", Toast.LENGTH_SHORT).show()
            // TODO: Implement water logging logic
            // After logging: Save new water value to SharedPreferences and call refreshData()
        }

        buttonAddBreakfast.setOnClickListener {
            Toast.makeText(context, "Add Breakfast clicked (Food Log)", Toast.LENGTH_SHORT).show()
            // TODO: Implement navigation to food logging screen for Breakfast
            // val intent = Intent(activity, FoodLogActivity::class.java) // Assuming FoodLogActivity exists
            // intent.putExtra("MEAL_TYPE", "Breakfast")
            // startActivity(intent)
        }

        buttonAddLunch.setOnClickListener {
            Toast.makeText(context, "Add Lunch clicked (Food Log)", Toast.LENGTH_SHORT).show()
            // TODO: Implement navigation to food logging screen for Lunch
            // val intent = Intent(activity, FoodLogActivity::class.java)
            // intent.putExtra("MEAL_TYPE", "Lunch")
            // startActivity(intent)
        }

        buttonAddDinner.setOnClickListener {
            Toast.makeText(context, "Add Dinner clicked (Food Log)", Toast.LENGTH_SHORT).show()
            // TODO: Implement navigation to food logging screen for Dinner
            // val intent = Intent(activity, FoodLogActivity::class.java)
            // intent.putExtra("MEAL_TYPE", "Dinner")
            // startActivity(intent)
        }
    }

    // Method to refresh data from outside
    fun refreshData() {
        if (isAdded) { // Check if fragment is attached
            loadAndDisplayData()
        }
    }
}