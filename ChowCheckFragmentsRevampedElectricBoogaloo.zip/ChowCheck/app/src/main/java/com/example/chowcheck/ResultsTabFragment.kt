package com.example.chowcheck

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment

class ResultsTabFragment : Fragment() {

    private lateinit var tabNameTextView: TextView
    private lateinit var tabDataTextView: TextView

    // Inflate the fragment layout and set the data for the tab
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_results_tab, container, false)

        tabNameTextView = view.findViewById(R.id.tabNameTextView)
        tabDataTextView = view.findViewById(R.id.tabDataTextView)

        // Retrieve the tab name and data from the arguments
        val tabName = arguments?.getString("TAB_NAME")
        val tabData = arguments?.getString("TAB_DATA")

        tabNameTextView.text = tabName ?: "No name"
        tabDataTextView.text = tabData ?: "No data"

        return view
    }
}
