package com.example.chowcheck

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.example.chowcheck.frag.DiaryFragment // Ensure correct import
import com.example.chowcheck.frag.FoodLogFragment // Ensure correct import
import com.example.chowcheck.frag.ProfileFragment // *** Ensure this import is CORRECT ***
import com.google.android.material.bottomnavigation.BottomNavigationView

class LandingActivity : AppCompatActivity() {

    private lateinit var bottomNavView: BottomNavigationView // Make it a member variable

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_landing)

        bottomNavView = findViewById(R.id.bottomNav) // Initialize here

        // Check if started from Settings to load a specific fragment
        val fragmentToLoad = intent.getStringExtra("LOAD_FRAGMENT")

        if (savedInstanceState == null && fragmentToLoad == null) {
            // Default start: Load Diary(Dashboard) Fragment initially
            bottomNavView.selectedItemId = R.id.navigation_diary
            replaceFragment(DiaryFragment())
        } else if (fragmentToLoad == "PROFILE") {
            // Started from Settings, wanting Profile: Select Profile in Nav
            // The listener below will handle loading the actual fragment
            bottomNavView.selectedItemId = R.id.navigation_profile
            // If the listener doesn't fire reliably on initial programmatic selection,
            // uncomment the line below:
            // replaceFragment(ProfileFragment())
        }
        // Add more 'else if' blocks here if other activities need to deep link to specific fragments

        // --- Listener Setup ---
        bottomNavView.setOnItemSelectedListener { item ->
            val selectedFragment: Fragment = when (item.itemId) {
                R.id.navigation_diary -> DiaryFragment()
                R.id.navigation_food_log -> FoodLogFragment()
                R.id.navigation_profile -> ProfileFragment()
                // Add cases for explore/results if needed
                else -> DiaryFragment()
            }
            replaceFragment(selectedFragment)
            true
        }

        bottomNavView.setOnItemReselectedListener { item ->
            // Handle reselection if needed
        }
    }

    private fun replaceFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, fragment)
            .commit()
    }
}